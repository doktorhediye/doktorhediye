# Doktor Hediye — ikas uygulama notları

14 Eylül 2026. Kullanıcı ikas seçti. Bu çalışma yerel tasarım önizlemesidir; ikas mağazasına, ödeme veya kargoya bağlı değildir. Domain DNS'i değiştirilmedi. Başlangıçta oluşturulan Sites kaydı yayımlanmadı; kullanıcının ikas tercihi sonrasında bu yoldan devam edilmedi.

## Hazır olanlar
- Türkçe, responsive monogram koleksiyonu tasarımı; doktor arama, hediye seçimi, not ekleme ve örnek takip ekranı.
- Üç yeni yapay zekâ görseli: bordo H.K. nakış, çift manşet/kol düğmesi, çizgili monogramlı gömlek.
- Görsellerden yavaş yakın plan ile oluşturulan 9 saniyelik ana video ve 15 saniyelik koleksiyon videosu. Gerçek çekim değildir.
- Resmî Mega dizininin 26 sayfasından 387 kayıt; fakülte bölüm sayfalarından 40 dal kaydı (39 farklı isim). Kayıtlar ad, kaynak, branş, kurum ve eşleşme adaylarıyla JSON ve Excel olarak saklandı.
- Fakültenin tam eğitim kadrosu sayfası veri yükleyemedi; erişilebilir bölüm/anabilim dalı başkanları ayrı kapsamla tutuldu.

## ikas'a uyarlama
Mağaza yönetim adresi ve oturum erişimi bekleniyor. Bu dosyalar doğrudan yüklenebilir ikas teması veya ikas ürün içe aktarım şablonu değildir. Mağazanın tema düzenleme ve kişiselleştirme olanakları görüldükten sonra uyarlanmalı.

ikas'ın resmî Ürün Kişiselleştirme özelliği siparişte metin/seçenek toplama olanağı sağlar: https://support.ikas.com/tr/urun-kisisellestirme
Hediye paketi ve sipariş notu ayarları: https://support.ikas.com/tr/musteri-ayarlari
Ürün özel alanları içerik/filtreleme amaçlıdır; müşteri tarafından girilen kişiselleştirme alanlarıyla karıştırılmamalı: https://support.ikas.com/tr/ozel-alanlar

Siparişe aktarılması gereken alanlar: doktor_kayit_id, doktor_adi, kurum_adi, brans, gonderen_adi, hediye_notu. Doktor araması için tema veya özel bileşen entegrasyonu ayrıca gerekir. Katalog JSON'u doktor müşteri hesabı değildir ve ikas müşteri listesi olarak içe aktarılmamalı.

Monogram harfleri ve ölçüler doktor hediye kabulünden sonra doğrulanmalı. Ödeme sonrası operasyon: kabul bekleniyor → ölçü/kumaş tercihi alındı → dikimde → kargoda → teslim edildi. Canlı kargo/bildirim/ödeme kurulumları yapılmadı. Hediye reddi halinde iade süreci işletme tarafından belirlenmeli.

## Veri kapsamı
Sadece kamuya açık mesleki ad, unvan, branş ve kurum verileri toplandı. Kişisel cep telefonu, ev adresi, ölçüler veya hasta bilgileri toplanmadı. Listede olmak hizmete katılım veya iş ortaklığı anlamına gelmez. Fakültede aynı isimli kayıtlar otomatik tek kişi kabul edilmedi; isim eşleşmeleri adaydır. Naci Karacaoğlan'ın fakülte kaynağında iki farklı dalda görünmesi kontrol notuyla işaretlendi. Kaynakta olmayan branşlar uydurulmadı.

## Canlıya geçiş için gerekenler
Mağaza erişimi, gerçek ürün/fiyat/kumaş bilgileri ve kol düğmesinin ürün kapsamına dahil olup olmadığı; ödeme/kargo bağlantıları; doktor kabulü ve ölçü toplama süreci; domain bağlantısı. Gerçek siparişle uçtan uca test tamamlanana kadar satış açılmamalı.

## Kol düğmesi — güncel tasarım kararı
Manşet Koleksiyonu (çift manşet) seçilince isteğe bağlı Siyah Oval kol düğmesi çifti sunulur. Varsayılan: ekleme. Prototipte gömlek 4.500 TL, ek ürün 1.250 TL, birlikte 5.750 TL; tüm fiyatlar örnektir. Klasik modellere geçince ek ürün temizlenir. Seçim geri düzenlemede korunur ve örnek takip özetine aktarılır.
Canlı ikas kurulumunda kol düğmesi stok takibi olan ayrı bir ürün/SKU olmalı; yalnız metin kişiselleştirme alanıyla ek bedel alınmamalı. Uygun model ilişkisi, sepet satırı, fiyatın sunucuda doğrulanması ve stok kontrolü mağazanın mevcut olanaklarıyla uygulanıp test edilmeli. Henüz ikas'a aktarım yapılmadı.
