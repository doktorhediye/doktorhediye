# Shopify ürünlerini ekleme

Tema ile ürün kayıtları farklı alanlardır. Bu yüzden tema ZIP’i görsel yapıyı yükler; ürünler ise Shopify **Products** ekranına eklenir.

1. Shopify’da **Products → Import** sayfasını açın.
2. `doktorhediye-shopify-urunler.csv` dosyasını seçin.
3. Dört ürün taslak olarak eklenir: Manşet Koleksiyonu, The Signature Gömlek, Çizgili İmza ve Siyah Oval Kol Düğmesi.
4. Her ürünün içine girerek temadaki karşılık gelen görseli yükleyin. Ürün görseli henüz yoksa tema, ürün sayfasında kendi yedek görselini gösterir; ana sayfadaki ürün kartları da görselleri ve bağlantılarıyla hazırdır.
5. Fiyat, stok, açıklama ve kargo bilgilerini kontrol edin; hazır olduğunda ürünleri **Active** durumuna alın.
6. **Products → Collections** içinde `The Personal Collection` adında koleksiyon oluşturup iki gömleği ekleyin. Ardından temada **Customize → Koleksiyon** bölümünden bu koleksiyonu seçin.

Ana sayfa bağlantıları CSV’deki ürün adresleriyle hazır eşleşir: `/products/signature-gomlek`, `/products/manset-koleksiyonu`, `/products/cizgili-imza` ve `/products/siyah-oval-kol-dugmesi`. Shopify **Customize → Doktor Hediye ana sayfa** alanından bunları daha sonra değiştirebilirsiniz.

Kol düğmesini gömleğe ücretli ek seçenek yapmak için Shopify’da ürün sayfasında paketleme/upsell uygulaması kullanın. Bu ürün ayrıca bağımsız olarak da satılabilir.

## Doktor listesini ekleme

1. **Settings → Custom data → Metaobjects → Add definition** açın.
2. Tanım adı ve türü `Doktor` / `doctor` olsun.
3. Üç adet tek satır metin alanı oluşturun: `full_name` (görüntü adı), `branch`, `institution`.
4. **Content → Metaobjects** alanına geçin ve Matrixify uygulamasıyla `doktorhediye-metaobjects.xlsx` dosyasını içe aktarın.
5. Shopify’da **Online Store → Pages → Add page** ile `Doktorlarımızı bulun` sayfasını oluşturun. Sayfa şablonunda `page.doctors` seçin; URL’si `/pages/doktorlar` olur.

Bu sayfa temadaki ana arama bağlantısına hazır bağlıdır. Yeni doktor eklemek veya düzenlemek için bundan sonra Content → Metaobjects → Doktor alanını kullanın.
