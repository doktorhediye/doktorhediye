# Doktor Hediye — Shopify Teması

Bu paket Shopify tema yükleyicisi için hazırlanmıştır. `doktorhediye-shopify-theme.zip` dosyasını **Online Store → Themes → Import theme → Upload zip file** yolundan yükleyin.

Yüklemeden sonra **Customize** alanında şunları yönetin:

- **Theme settings → Doktor Hediye:** marka metinleri, renkler ve ana menü.
- **Home page:** giriş görseli, metinler, hikâye alanı, kişisel kart ve öne çıkan koleksiyon.
- **Products / Collections:** gerçek ürün, fiyat, stok, fotoğraf ve koleksiyon içerikleri.

Tema başlangıç tasarımıdır. Ödeme, kargo, vergi, alan adı ve sipariş yönetimi Shopify panelinden yürütülür. Doktor seçimi içindeki arama alanı örnek Medipol kayıtlarını içerir; ürün sayfasındaki doktor adı ve kart notu alanları ise siparişin ürün bilgisiyle birlikte kaydedilir. Ürünleri mağazaya eklemek için tema paketinin yanındaki `doktorhediye-shopify-urunler.csv` dosyasını Shopify Products → Import alanından içe aktarın.
