<?php
if (!defined('ABSPATH')) exit;
define('DH_VERSION', '1.0.0');
function dh_setup(){
  add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('woocommerce');
  register_nav_menus(array('primary'=>__('Ana Menü','doktorhediye')));
}
add_action('after_setup_theme','dh_setup');
function dh_assets(){
  wp_enqueue_style('doktorhediye',get_stylesheet_uri(),array(),DH_VERSION);
  wp_enqueue_script('doktorhediye',get_template_directory_uri().'/assets/theme.js',array(),DH_VERSION,true);
  wp_localize_script('doktorhediye','dhSite',array('doctors'=>get_template_directory_uri().'/assets/doctors.json','shop'=>function_exists('wc_get_page_permalink')?wc_get_page_permalink('shop'):home_url('/magaza/')));
}
add_action('wp_enqueue_scripts','dh_assets');
function dh_customize($c){
  $c->add_section('dh_home',array('title'=>'Doktor Hediye Ana Sayfa','priority'=>30));
  $fields=array('hero_title'=>'Giriş başlığı','hero_text'=>'Giriş metni','hero_button'=>'Giriş düğmesi','story_title'=>'Hediye hikâyesi başlığı','story_text'=>'Hediye hikâyesi metni','footer_text'=>'Alt bilgi metni');
  foreach($fields as $id=>$label){$c->add_setting('dh_'.$id,array('default'=>'' ,'sanitize_callback'=>'sanitize_textarea_field'));$c->add_control('dh_'.$id,array('label'=>$label,'section'=>'dh_home','type'=>$id==='hero_text'||$id==='story_text'?'textarea':'text'));}
  $c->add_setting('dh_hero_image',array('sanitize_callback'=>'esc_url_raw'));$c->add_control(new WP_Customize_Image_Control($c,'dh_hero_image',array('label'=>'Giriş fotoğrafı','section'=>'dh_home')));
}
add_action('customize_register','dh_customize');
function dh_val($key,$fallback){$value=get_theme_mod('dh_'.$key);return $value!==''?$value:$fallback;}
function dh_default_menu(){
  echo '<a href="'.esc_url(home_url('/#koleksiyon')).'">Koleksiyon</a><a href="'.esc_url(home_url('/#nasil')).'">Nasıl çalışır?</a><a href="'.esc_url(function_exists('wc_get_page_permalink')?wc_get_page_permalink('shop'):home_url('/magaza/')).'">Mağaza</a>';
}
