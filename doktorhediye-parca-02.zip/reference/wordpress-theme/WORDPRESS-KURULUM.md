# Doktor Hediye WordPress kurulumu

Bu klasördeki `doktorhediye` tema klasörü, mevcut tasarımın WordPress ve WooCommerce uyumlu sürümüdür. Yönetim paneli WordPress'te `https://doktorhediye.com/wp-admin` olur.

## Önce hosting alın

TürkTicaret.net'teki domain tek başına WordPress çalıştırmaz. PHP 8.1+, MySQL/MariaDB, ücretsiz SSL ve dosya yöneticisi sunan bir WordPress hosting paketi alın. Satın alma sırasında alan adı olarak `doktorhediye.com` seçin.

## Domaini hostinge bağlayın

Hosting şirketi iki nameserver adresi verir. TürkTicaret.net panelinde Alan Adlarım > doktorhediye.com > Nameserver/DNS bölümünden mevcut nameserver değerlerini hosting firmasının verdiği değerlerle değiştirin. Domain zaten başka bir e-posta veya hizmet için kullanılıyorsa önce o DNS kayıtlarını not edin. DNS yayılımı birkaç saat, nadiren 24 saat sürebilir.

## WordPress'i kurun

Hosting panelinden WordPress Installer/Softaculous seçin ve domain olarak `doktorhediye.com` seçin. Yönetici kullanıcı adı ve güçlü şifrenizi belirleyin. Kurulumdan sonra `https://doktorhediye.com/wp-admin` adresine giriş yapın.

## Temayı yükleyin

1. Bu klasördeki `doktorhediye` klasörünü ZIP yapın. Klasörün içindeki `style.css` dosyası ZIP'in en üst seviyesinde olacak şekilde paketleyin.
2. WordPress > Görünüm > Temalar > Yeni Tema Ekle > Tema Yükle yolunu açın.
3. ZIP dosyasını yükleyin ve Etkinleştir'e basın.
4. Görünüm > Özelleştir > Doktor Hediye Ana Sayfa bölümünden giriş başlığını, metnini ve görselini değiştirin.
5. Görünüm > Menüler bölümünde bir "Ana Menü" oluşturup Menü Konumu olarak "Ana Menü"yü seçin. Buradan tüm üst menü linklerini, sayfaları ve dış bağlantıları kod yazmadan değiştirirsiniz.

## Mağaza ve ödeme

1. Eklentiler > Yeni Ekle'den WooCommerce'i kurun.
2. WooCommerce kurulum sihirbazında para birimini TRY yapın.
3. Ürünler > Yeni Ekle'den gömlek ve kol düğmelerini ekleyin. Ana sayfa üç yayındaki ürünü otomatik gösterir.
4. Ödeme için seçtiğiniz sağlayıcının resmî WooCommerce eklentisini kurun. Sağlayıcının işletme, kimlik, vergi ve sözleşme koşulları bağımsızdır; ödeme aktifleşmeden önce test siparişi yapın.
5. Kargo, iade, mesafeli satış, gizlilik/KVKK ve iletişim sayfalarını gerçek işletme bilgilerinizle tamamlayın.

## Doktor araması

Tema ilk sürümde `assets/doctors.json` listesini kullanır. Yeni doktor kaydı eklemek için bu dosyayı teknik destekle güncelleyin veya sonraki aşamada doktorları WordPress yönetim alanına taşıyan özel modül ekleyin. Kamuya açık profesyonel veriler dışında iletişim, ev adresi, ölçü veya sağlık bilgisi tutmayın.
