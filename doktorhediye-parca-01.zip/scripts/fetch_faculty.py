"""Read the public directory via the same endpoint used by the official page."""
import urllib.request, urllib.parse, http.cookiejar, json
from pathlib import Path
base='https://www.medipol.edu.tr/'
opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
opener.addheaders=[('User-Agent','Mozilla/5.0')]
token=opener.open(base+'session/token',timeout=30).read().decode()
body=json.dumps({'plugin_id':'medipol_egitim_kadrosu_block','block_id':'egitim_kadrosu_config_key_323','settings':{'program':'323'}}).encode()
r=urllib.request.Request(base+'ajax/egitim-kadrosu',data=body,headers={'Content-Type':'application/json','X-CSRF-Token':token})
result=opener.open(r,timeout=45).read()
Path('/tmp/medipol-faculty-response.json').write_bytes(result)
print('Public directory response saved:',len(result),'bytes')
