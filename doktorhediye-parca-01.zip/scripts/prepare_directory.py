from pathlib import Path
from lxml import html
from collections import Counter
import json,re,unicodedata,hashlib
OUT=Path('data');OUT.mkdir(exist_ok=True)
def clean(s):return re.sub(r'\s+',' ',s).strip()
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',s.lower().replace('ı','i')) if not unicodedata.combining(c))
def txtnode(e):
 return clean(' '.join(e.xpath('.//text()[not(ancestor::span[contains(@class,"item-size")])]')))
hospital=[];counts=[]
for i in range(26):
 p=Path('/tmp/medipol-mega'+(('-'+str(i)) if i else '')+'.html');s=html.parse(str(p))
 cards=s.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," doctor-list-card ")]');counts.append(len(cards))
 for c in cards:
  a=c.xpath('.//h5/a')[0];parts=[clean(t) for t in a.itertext() if clean(t)];title,name=(parts[0],clean(' '.join(parts[1:]))) if len(parts)>1 else ('Belirtilmemiş',parts[0])
  depts=c.xpath('./div[contains(@class,"position-relative")]/div[contains(@class,"department")]')
  def fields(d):
   p=d.xpath('./p');first=d.xpath('.//span[contains(@class,"first-hospital")]');other=d.xpath('.//div[contains(@class,"other-items")]//small')
   return [txtnode(x) for x in p+first+other]
  branches=fields(depts[0]) if len(depts)>1 else ['Branş belirtilmemiş'];hospitals=fields(depts[-1]);assert 'Medipol Mega Üniversite Hastanesi' in hospitals,(i,name,hospitals)
  typ='Hekim' if ('Dr.' in title or title=='Doktor Öğretim Üyesi' or title=='Asistan Hekim') else 'Unvan/meslek teyidi gerekli'
  if title=='Dt.' or any(any(t in norm(b) for t in ['dis ','discil','pedodont','periodont','ortodont','endodont']) for b in branches):typ='Diş hekimi'
  if any(t in norm(title) for t in ['diyetisyen','psikolog','fizyoterapist']):typ='Diğer sağlık profesyoneli'
  hospital.append(dict(id=a.get('href').rsplit('/',1)[-1],name=name,title=title,branches=branches,branch=' / '.join(branches),institution='Medipol Mega Üniversite Hastanesi',hospitals=hospitals,type=typ,source=a.get('href'),listing='https://medipol.com.tr/doktorlarimiz/medipol-mega-universite-hastanesi-doktorlari'+(f'?HospitalId=18&page={i}' if i else ''),scope='Mega doktor dizini',group='',note=('Branş kaynak listede eksik; profil veya kurum teyidi gerekli.' if branches==['Branş belirtilmemiş'] else ''),checked='2026-09-14'))
assert len({r['id'] for r in hospital})==len(hospital)
faculty=[]
for f,group in [('temel','Temel Tıp Bilimleri'),('dahili','Dahili Tıp Bilimleri'),('cerrahi','Cerrahi Tıp Bilimleri')]:
 s=html.parse('/tmp/medipol-'+f+'.html');url='https://www.medipol.edu.tr/akademik/fakulteler/tip-fakultesi/bolumler/'+f+'-tip-bilimleri'
 for h in s.xpath('//h3[contains(@class,"profile-card__title")]'):
  whole=clean(h.text_content());m=re.match(r'^(Prof\.?\s*Dr\.?|Doç\.?\s*Dr\.?|Dr\.?\s*Öğr\.?\s*Üyesi)\s*(.*)$',whole);assert m,whole
  title,name=m.groups();ps=h.getparent().xpath('./p');branch=clean(ps[-1].text_content()).split(' Anabilim')[0]
  faculty.append(dict(id='faculty-'+hashlib.sha1((name+group).encode()).hexdigest()[:12],name=name,title=title,branches=[branch],branch=branch,institution='İstanbul Medipol Üniversitesi Tıp Fakültesi',hospitals=[],type='Akademisyen; hekimlik teyidi gerekebilir',source=url,listing=url,scope='Anabilim dalı başkanları; tam kadro değildir',group=group,note='',checked='2026-09-14'))
for r in faculty:
 matches=[h for h in hospital if norm(h['name'])==norm(r['name'])]
 r['candidate_ids']=[h['id'] for h in matches]
 r['match']='İsim eşleşmesi adayı; kurum bağı ayrıca doğrulanmalı' if matches else 'Mega listesinde tam isim eşleşmesi yok'
 if norm(r['name'])=='naci karacaoglan': r['note']='Kaynakta aynı isim iki farklı dalda yer alıyor; dal doğrulanmalı.'
for r in hospital:
 matches=[f for f in faculty if norm(f['name'])==norm(r['name'])];r['candidate_ids']=[f['id'] for f in matches];r['match']='Fakülte listesinde isim eşleşmesi adayı' if matches else 'Fakülte bölüm listesinde tam isim eşleşmesi yok'
allrows=hospital+faculty
for r in allrows: assert r['name'] and r['title'] and r['branches'],r
allrows.sort(key=lambda r:(r['institution'],norm(r['branch']),norm(r['name'])))
OUT.joinpath('medipol-directory.json').write_text(json.dumps(allrows,ensure_ascii=False,indent=2))
# Exclude ambiguous faculty records from gift selection; preserve all in research directory.
public=[r for r in hospital if r['type'] in ['Hekim','Diş hekimi']]
Path('dist/doctors.json').write_text(json.dumps(public,ensure_ascii=False))
Path('dist/directory.json').write_text(json.dumps(allrows,ensure_ascii=False))
summary={'mega_records':len(hospital),'mega_types':dict(Counter(r['type'] for r in hospital)),'faculty_rows':len(faculty),'faculty_unique_names':len({norm(r['name']) for r in faculty}),'faculty_name_matches':len({norm(r['name']) for r in faculty if r['candidate_ids']}),'total_source_rows':len(allrows),'mega_pages':len(counts),'page_counts':counts,'faculty_scope':'Bölüm/anabilim dalı başkanları. Eğitim Kadrosu sayfası ve kamuya açık AJAX uç noktası yüklenmedi (HTTP 500). Tam fakülte kadrosu değildir.'}
OUT.joinpath('summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False))
