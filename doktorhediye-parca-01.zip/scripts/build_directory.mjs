import fs from 'node:fs/promises';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const rows=JSON.parse(await fs.readFile('data/medipol-directory.json','utf8'));
const dir='outputs/01a09edf-3e31-7bd3-85fc-c007607e5f5d';
await fs.mkdir(dir,{recursive:true});
const wb=Workbook.create();
for(const [name,scope] of [['Mega Hastanesi','Mega doktor dizini'],['Fakülte Bölümleri','Anabilim dalı başkanları; tam kadro değildir']]){
 const data=rows.filter(r=>r.scope===scope);
 const s=wb.worksheets.add(name);s.showGridLines=false;s.tabColor='#592B39';
 s.getRange('A2').values=[[name==='Mega Hastanesi'?'Medipol Mega · Doktor dizini':'Tıp Fakültesi · Bölüm kadroları']];
 s.getRange('A3').values=[['14.09.2026 · '+(name==='Mega Hastanesi'?'387 kayıt; hekim, diş hekimi ve diğer unvanlar ayrı sınıflandırıldı.':'40 dal kaydı, 39 farklı isim. Tam eğitim kadrosu değildir.')]];
 const headers=['Ad Soyad','Unvan','Branş / Anabilim Dalı','Kurum','Ek hastaneler','Kayıt türü','Bölüm','Eşleşme durumu','Kontrol notu','','Kaynak sayfa','Profil / bölüm kaynağı'];
 const values=data.map(r=>[r.name,r.title,r.branch,r.institution,r.hospitals.filter(h=>h!==r.institution).join(' / '),r.type,r.group,r.match,r.note,'',r.listing,r.source]);
 s.getRange('A5:L5').values=[headers];s.getRange(`A6:L${data.length+5}`).values=values;
 s.getRange(`A2:L${data.length+5}`).format.font={name:'Arial',size:11,color:'#302927'};
 s.getRange('A2').format.font={name:'Arial',size:16,color:'#592B39'};
 s.getRange('A3').format.font={name:'Arial',size:11,italic:true,color:'#736C65'};
 s.getRange(`A5:I${data.length+5}`).format.rowHeight=54;
 s.getRange(`A5:I${data.length+5}`).format.wrapText=true;
 s.getRange(`A5:I${data.length+5}`).format.verticalAlignment='center';
 const widths=[31,23,40,44,40,30,27,40,55,3,85,85];
 widths.forEach((w,i)=>s.getRangeByIndexes(4,i,data.length+1,1).format.columnWidth=w);
 const table=s.tables.add(`A5:I${data.length+5}`,true,name==='Mega Hastanesi'?'MegaDoktorlar':'FakulteKayitlari');table.showFilterButton=true;
 s.getRange('A5:I5').format={fill:'#592B39',font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',wrapText:true};
 s.getRange(`K5:L${data.length+5}`).format.font={name:'Arial',size:10,color:'#666666'};
 s.freezePanes.freezeRows(5);s.freezePanes.freezeColumns(2);
 s.getRange(`I6:I${data.length+5}`).conditionalFormats.add('notContainsBlanks',{format:{fill:'#FFF0D8',font:{color:'#784817'}}});
}
wb.recalculate();
console.log((await wb.inspect({kind:'table',range:"'Mega Hastanesi'!A5:D8",tableMaxRows:4,tableMaxCols:4,maxChars:1300})).ndjson);
for(const [name,file] of [['Mega Hastanesi','mega-preview.png'],['Fakülte Bölümleri','faculty-preview.png']]){
 const img=await wb.render({sheetName:name,range:'A1:D10',scale:1.5,format:'png'});await fs.writeFile(`${dir}/${file}`,new Uint8Array(await img.arrayBuffer()));
}
const out=await SpreadsheetFile.exportXlsx(wb);await out.save(`${dir}/Medipol-Doktor-Listesi.xlsx`);
console.log('Exported 427 source records, 2 sheets.');
