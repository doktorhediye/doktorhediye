# Yeni görseller — 14 Eylül 2026

Yöntem: yerleşik ImageGen aracı. Görseller yapay zekâyla üretilmiş sunum konseptleridir. Model gerçek bir doktoru temsil etmez.

## Kaydedilenler
- ../dist/assets/gift-open.png — Açık bordo hediye kutusu, H.K. nakışlı ekru gömlek, kâğıt ve kişisel not kartı.
- ../dist/assets/doctor-man.png — Beyaz özel dikim H.K. monogramlı gömlek giymiş temsili erkek doktor.

## Üretim briefleri
1. Landscape 3:2 open dark burgundy rigid gift box with folded ivory bespoke shirt, subtle italic H.K. cuff embroidery, silk tissue and blank small note, espresso wood, quiet luxury. Photorealistic, warm light, no logos or text except H.K.
2. Portrait fictional male doctor age about 40 wearing beautifully tailored white shirt with subtle H.K. cuff embroidery and navy tailored trousers in elegant warm private medical office, stethoscope subtly on desk, relaxed candid professional expression, no labcoat so shirt visible, not an identifiable real doctor. No hospital logos.

Kapalı hediye kutusu ve kadın doktor için istenen diğer iki görsel üretim kotası nedeniyle oluşmadı. Bu görseller için boş yer bırakılmadı. Mevcut çizgili manşet görseli stil bölümünde, mevcut gömlek ve not görseli hediye sunumu bölümünde yeniden kullanıldı.

## 14 Eylül — lacivert kutu ve kol düğmesi revizyonu
Built-in image_gen kullanıldı. Dört başarılı üretim/düzenleme; CLI kullanılmadı. Yeni görseller dist/assets altında saklandı:
- gift-navy-cuff.png: ilk kullanıcı referansının düzenlemesi. Brief: lacivert kutu, krem iç yüzey, Türkçe yazılar ve gömleği koru; alt soldaki manşeti gerçekçi çift manşet yap, görünür gümüş tonlu siyah kol düğmesi ve küçük hafif italik H.K. ekle.
- cufflinks.png: yeni ürün görseli. Brief: lacivert dokulu küçük kutu, şampanya rengi iç yüzey, biri önden biri mekanizması görünür bir çift oval siyah/gümüş tonlu kol düğmesi; taş masa, sıcak ışık, yazısız premium ürün çekimi.
- monogram-button.png: ana görsel düzeltmesi. Brief: el, kumaş, ışık ve kadrajı koru; manşete gerçek dikili krem düğme, ilik ve doğru örtüşen manşet uçları ekle; bordo H.K. hafif italik olsun.
- personal-label.png: yeni etiket görseli. Brief: ekru gömlek yaka içinde şampanya pamuk etiket, tam metin “İyi ki varsınız.” ve altında “doktor hediye”; ince dikiş, önde H.K. monogram ve dikili düğme; sıcak ışık, portre kadraj.
- gift-navy-lid.png: kullanıcının 11_31_05 AM adlı üçüncü referansının değiştirilmeden kopyası; yeni üretim değildir.
Yeni videolar monogram-button-film.mp4 ve collection-film-v2.mp4, düzeltilmiş fotoğraftan üretilen yavaş yakın plan animasyonlarıdır.
Kontrol: tarayıcıda varsayılan 4.500 TL, ek ürünle 5.750 TL, ek ürünü kaldırınca 4.500 TL; düzenlemede seçim korundu, takip özetine aktarıldı; klasik gömlekte ek ürün görünmedi ve toplam 3.500 TL.

## Doğal Signature ve gönderen etiketi
Built-in image_gen ile iki çıktı alındı (CLI kullanılmadı):
- dist/assets/signature-natural.png: yeni gerçekçi gün ışığı editorial fotoğraf. Prompt: ivory tailored cotton shirt on relaxed seated adult man, small correctly scaled sewn ivory barrel cuff button, subtly italic burgundy H.K., natural folds and skin, cream/taupe/navy, landscape composition, no artificial CGI button.
- dist/assets/personal-label-sender.png: mevcut etiket fotoğrafının düzenlemesi. Prompt: preserve shirt, navy box, light, framing and H.K.; below “İyi ki varsınız.” add smaller exact “Hastanız Hasan KARA'dan”, above “doktor hediye”; realistic printing on same sewn label.
Giriş ve Signature yeni fotoğrafı kullanır; sayfadaki videolar fotoğrafla değiştirildi. Etiket gönderen adı açıklaması detaylara eklendi. Büyük lacivert zemin yerine sürekli kırık beyaz/taş tonları kullanıldı.
