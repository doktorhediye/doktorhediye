# Doktor Hediye

GitHub'da düzenlenebilir, fotoğraf kullanan statik web sitesi. Mevcut tasarım, bölüm sırası, metinler ve görsel konumları korunmuştur. Derleme veya npm kurulumu gerektirmez.

## Bilgisayarınızda açma

Python 3 kuruluysa bu klasörde çalıştırın:

```sh
python3 -m http.server 4173
```

Ardından http://localhost:4173 adresini açın. HTML dosyasına çift tıklamak yerine sunucu kullanın; doktor listeleri JSON dosyalarından yüklenir.

## GitHub'a yükleme

ZIP'i bilgisayarınızda açın. İçindeki dosya ve klasörleri GitHub deposunun köküne yükleyin; ZIP dosyasını tek başına yüklemek siteyi çalıştırmaz. `index.html`, `assets`, `doctors.json` ve `directory.json` aynı yapı içinde kalmalıdır. `reference` ve `data` klasörleri arşiv ve sonraki düzenlemeler içindir.

GitHub Pages kullanacaksanız depo ayarlarında Pages kaynağını **Deploy from a branch**, kendi dalınızı ve **/ (root)** olarak seçin. GitHub Pages erişiminin hesap/depo koşulları geçerlidir. Alan adı otomatik değiştirilmez.

## Nereleri düzenlemeli?

- `index.html`: ana sayfa, ürün kartları, fiyat yazıları, içerik ve fotoğraf konumları.
- `style.css`: renkler, yazı tipleri, boyutlar, mobil düzen.
- `app.js`: doktor arama, ürün seçimi, kol düğmesi ekleme, örnek toplam ve takip. Ürün fiyatları değişince hem HTML hem buradaki fiyat tanımları güncellenmeli.
- `doktorlar.html`, `directory.js`: doktor dizini ve kurum/branş filtreleri.
- `doctors.json`: hediye seçiminde kullanılan 373 kayıt.
- `directory.json`: kaynak kapsamındaki 427 dizin kaydı; bunlar tekil kişi sayısı değildir.
- `data/medipol-directory.json`, `data/sources/`: kaynaklı ana veri ve alınmış kaynak sayfaları.
- `Medipol-Doktor-Listesi.xlsx`: mevcut Excel doktor listesi.
- `assets/`: fotoğraflar. Sayfa uzak görsel servisine bağlı değildir.
- `reference/`: önceki ikas notları, Shopify/WordPress kaynakları ve ürün/veri içe aktarma dosyaları. Bunlar ana statik sitenin çalışması için gerekli değildir.

## Fotoğraflar

Paket alındığı anda mevcut sitede video öğesi bulunmuyordu. Girişteki `signature-natural.png` ve detay bölümündeki `french-cuff.png` dosyaları yeniden üretilmeden, kırpılmadan veya yerleri değiştirilmeden aynen korundu. Video dosyaları ve video üretme betiği pakete eklenmedi. Eski videonun tüm hareketini tek fotoğraf temsil edemez; burada onaylanan mevcut fotoğraf görünümü korunur.

## Veri ve siparişler

Doktorlar dosyalarla birlikte taşınır; başka bir veritabanı kurulumu gerektirmez. Fakülte verisi erişilebilen kaynaklarla sınırlıdır; kaynak notları korunur. Sayfadaki gönderen bilgileri ve deneme siparişleri yalnızca tarayıcı belleğindedir, kalıcı sipariş veritabanı değildir. Gerçek ödeme, kargo veya ikas bağlantısı bulunmaz; fiyatlar örnektir.

`MANIFEST.json` paketteki dosyaların SHA-256 özetlerini içerir.
